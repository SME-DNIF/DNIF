if [[ $EUID -ne 0 ]]; then
	echo -e "This script must be run as root ... \e[1;31m[ERROR] \e[0m\n"
    exit 1
else
    os=$(. /etc/os-release && echo -e "$ID")
    dateis=$(date '+%Y-%m-%dT%H:%M:%S')
    #variable depending on OS and Container
    #LOG_FILE="/DNIF/Activity/log/Activity.log"
  
    if [ $os == "ubuntu" ]; then
        PCN=$(docker ps -a --format '{{.Names}}' | grep -w pico-v9)
        ACN=$(docker ps -a --format '{{.Names}}' | grep -w adapter-v9)
        DCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-v9)
        MDCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        CCN=$(docker ps -a --format '{{.Names}}' | grep -w core-v9)
        LCCN=$(docker ps -a --format '{{.Names}}' | grep -w console-v9)
        #PCID=$(docker ps -aqf "name=pico-v9") 
        #ACID=$(docker ps -aqf "name=adapter-v9")
        #DCID=$(docker ps -aqf "name=datanode-v9")
        #CCID=$(docker ps -aqf "name=core-v9")
        #MDCID=$(docker ps -aqf "name=datanode-master-v9")
        #LCCID=$(docker ps -aqf "name=console-v9")
    fi

    if [ $os == "centos" ]; then
        PCN=$(docker ps -a --format '{{.Names}}' | grep -w pico-v9)
        ACN=$(docker ps -a --format '{{.Names}}' | grep -w adapter-v9)
        DCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-v9)
        MDCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        CCN=$(docker ps -a --format '{{.Names}}' | grep -w core-v9)
        LCCN=$(docker ps -a --format '{{.Names}}' | grep -w console-v9)
        #PCID=$(docker ps -aqf "name=pico-v9") 
        #ACID=$(docker ps -aqf "name=adapter-v9")
        #DCID=$(docker ps -aqf "name=datanode-v9")
        #CCID=$(docker ps -aqf "name=core-v9")
        #MDCID=$(docker ps -aqf "name=datanode-master-v9")
        #LCCID=$(docker ps -aqf "name=console-v9")
    fi    
    
    if [ $os == "rhel" ]; then
        PPCN=$(podman ps -a --format '{{.Names}}' | grep -w pico-v9)
        PACN=$(podman ps -a --format '{{.Names}}' | grep -w adapter-v9)
        PDCN=$(podman ps -a --format '{{.Names}}' | grep -w datanode-v9)
        PMDCN=$(podman ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        PCCN=$(podman ps -a --format '{{.Names}}' | grep -w core-v9)
        PLCCN=$(podman ps -a --format '{{.Names}}' | grep -w console-v9)
        #PPCID=$(podman ps -aqf "name=pico-v9") 
        #PACID=$(podman ps -aqf "name=adapter-v9")
        #PDCID=$(podman ps -aqf "name=datanode-v9")
        #PCCID=$(podman ps -aqf "name=core-v9")
        #PMDCID=$(podman ps -aqf "name=datanode-master-v9")
        #PLCCID=$(podman ps -aqf "name=console-v9")   
    fi

function pre_act_containarconf() {
    proxy_check_true=$(grep "#http_proxy = true" /usr/share/containers/containers.conf)
    proxy_check_false=$(grep "http_proxy = false" /usr/share/containers/containers.conf)

    echo "$dateis info proxy_check_true: $proxy_check_true" >> $LOG_FILE
    echo "$dateis info proxy_check_false: $proxy_check_false" >> $LOG_FILE

    cp /usr/share/containers/containers.conf /DNIF/backup/containers.conf_dnif_pre_act
    file_check=$(ls /DNIF/backup/ | grep -i "containers.conf_dnif_pre_act")

    if [[ $file_check == "containers.conf_dnif_pre_act" ]]; then
        echo "$dateis info Continers.conf successfully copied from /usr/share/containers/containers.conf to /DNIF/backup/containers.conf_dnif_pre_act" >> $LOG_FILE
    else
        echo "$dateis info Continers.conf not successfully copied from /usr/share/containers/containers.conf to /DNIF/backup/" >> $LOG_FILE
    fi
}
    #---------------------------------------------------------
    if [[ $os == "ubuntu" ]] && [[ $PCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        docker stop pico-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $PCN and ID $PCID is stopped"
                echo $dateis "info" "container with name $PCN is stopped." >> $LOG_FILE
                echo "DNIF PICO Docker container is stopped"
            else
                #echo -e "container with name $PCN and ID $PCID is not stopped"
                echo $dateis "info" "container with name $PCN is not stopped." >> $LOG_FILE
                echo "DNIF PICO Docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $PCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        docker stop pico-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $PCN and ID $PCID is stopped"
                echo $dateis "info" "container with name $PCN is stopped." >> $LOG_FILE
                echo "DNIF PICO Docker container is stopped"
            else
                #echo -e "container with name $PCN and ID $PCID is not stopped"
                echo $dateis "info" "container with name $PCN is not stopped." >> $LOG_FILE
                echo "DNIF PICO Docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PPCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        podman stop pico-v9 >> $LOG_FILE
        sleep 10
        container_status=$(podman ps -a --filter "name=pico-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $PCN and ID $PCID is stopped"
                echo $dateis "info" "container with name $PPCN is stopped." >> $LOG_FILE
                echo "DNIF PICO Podman container is stopped"
            else
                #echo -e "container with name $PCN and ID $PCID is not stopped"
                echo $dateis "info" "container with name $PPCN is not stopped." >> $LOG_FILE
                echo "DNIF PICO Podman container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        pre_act_containarconf
    fi
    #------------------------------------------------------------------
    if [[ $os == "ubuntu" ]] && [[ $ACN == "adapter-v9" ]]; then
        LOG_FILE="/DNIF/AD/log/Activity.log"
        docker stop adapter-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $ACN is stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $ACN is not stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $ACN == "adapter-v9" ]]; then
        LOG_FILE="/DNIF/AD/log/Activity.log"
        docker stop adapter-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $ACN is stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $ACN is not stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhle" ]] && [[ $PACN == "adapter-v9" ]]; then
        LOG_FILE="/DNIF/AD/log/Activity.log"
        podman stop adapter-v9 >> $LOG_FILE
        sleep 10
        container_status=$(podman ps -a --filter "name=adapter-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $PACN is stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $PACN is not stopped." >> $LOG_FILE
                echo "DNIF Adapter Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        pre_act_containarconf
    fi
#----------------------------------------------------------------
    if [[ $os == "ubuntu" ]] && [[ $DCN == "datanode-v9" ]]; then
        LOG_FILE="/DNIF/DL/log/Activity.log"
        docker stop datanode-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $DCN is stopped." >> $LOG_FILE
                echo "DNIF Datnode Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $DCN is not stopped." >> $LOG_FILE
                echo "DNIF Datanode Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $DCN == "datanode-v9" ]]; then
        LOG_FILE="/DNIF/DL/log/Activity.log"
        docker stop datanode-v9 >> $LOG_FILE
        sleep 10
        container_status=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $DCN is stopped." >> $LOG_FILE
                echo "DNIF datanode Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $DCN is not stopped." >> $LOG_FILE
                echo "DNIF datanode Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PACN == "datanode-v9" ]]; then
        LOG_FILE="/DNIF/DL/log/Activity.log"
        podman stop datanode-v9 >> $LOG_FILE
        sleep 10
        container_status=$(podman ps -a --filter "name=datanode-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "$dateis : container with name $ACN and ID $ACID is stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is stopped."
                echo $dateis "info" "container with name $PDCN is stopped." >> $LOG_FILE
                echo "DNIF datanode Docker container is stopped"
            else
                #echo -e "$dateis : container with name $ACN and ID $ACID is not stopped" >> /DNIF/AD/log/Activity.log
                #log_message "info" "container with name $ACN is not stopped."
                echo $dateis "info" "container with name $PDCN is not stopped." >> $LOG_FILE
                echo "DNIF datanode Docker container is NOT stopped"
            fi
        #echo -e "$dateis : $(docker ps -a)" >> /DNIF/AD/log/Activity.log
        #log_message "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        pre_act_containarconf
    fi

#-----------------------------

    if [[ $os == "ubuntu" ]] && [[ $CCN == "core-v9" ]]; then       
        LOG_FILE="/DNIF/CO/log/Activity.log"
        docker stop datanode-master-v9 >> $LOG_FILE
        docker stop core-v9 >> $LOG_FILE
        sleep 10
        container_status_mdn=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")

            if [[ $container_status_mdn == *"Exited"* ]]; then      
                #echo -e "container with name $MDCN and ID $MDCID is stopped"
                echo $dateis "info" "container with name $MDCN is stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 Docker container is stopped"
            else
                #echo -e "container with name $MDCN and ID $MDCID is not stopped"
                echo $dateis "info" "container with name $MDCN is NOT stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 Docker container is NOT stopped"
            fi
            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $CCN and ID $CCID is stopped"
                echo $dateis "info" "container with name $CCN is stopped." >> $LOG_FILE
                echo "DNIF core-v9 Docker container is stopped"
            else
                #echo -e "container with name $CCN and ID $CCID is not stopped"
                echo $dateis "info" "container with name $CCN is NOT stopped." >> $LOG_FILE
                echo "DNIF core-v9 Docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi


    if [[ $os == "centos" ]] && [[ $CCN == "core-v9" ]]; then       
        LOG_FILE="/DNIF/CO/log/Activity.log"
        docker stop datanode-master-v9 >> $LOG_FILE
        docker stop core-v9 >> $LOG_FILE
        sleep 10
        container_status_mdn=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")

            if [[ $container_status_mdn == *"Exited"* ]]; then      
                #echo -e "container with name $MDCN and ID $MDCID is stopped"
                echo $dateis "info" "container with name $MDCN is stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 Docker container is stopped"
            else
                #echo -e "container with name $MDCN and ID $MDCID is not stopped"
                echo $dateis "info" "container with name $MDCN is NOT stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 Docker container is NOT stopped"
            fi
            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $CCN and ID $CCID is stopped"
                echo $dateis "info" "container with name $CCN is stopped." >> $LOG_FILE
                echo "DNIF core-v9 Docker container is stopped"
            else
                #echo -e "container with name $CCN and ID $CCID is not stopped"
                echo $dateis "info" "container with name $CCN is NOT stopped." >> $LOG_FILE
                echo "DNIF core-v9 Docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi


    if [[ $os == "rhel" ]] && [[ $PCCN == "core-v9" ]]; then       
        LOG_FILE="/DNIF/CO/log/Activity.log"
        podman stop datanode-master-v9 >> $LOG_FILE
        podman stop core-v9 >> $LOG_FILE
        sleep 10
        container_status_mdn=$(podman ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(podman ps -a --filter "name=core-v9" --format "{{.Status}}")

            if [[ $container_status_mdn == *"Exited"* ]]; then      
                #echo -e "container with name $MDCN and ID $MDCID is stopped"
                echo $dateis "info" "container with name $PMDCN is stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 podman container is stopped"
            else
                #echo -e "container with name $MDCN and ID $MDCID is not stopped"
                echo $dateis "info" "container with name $PMDCN is NOT stopped." >> $LOG_FILE
                echo "DNIF datanode-master-v9 podman container is NOT stopped"
            fi
            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $CCN and ID $CCID is stopped"
                echo $dateis "info" "container with name $PCCN is stopped." >> $LOG_FILE
                echo "DNIF core-v9 podman container is stopped"
            else
                #echo -e "container with name $CCN and ID $CCID is not stopped"
                echo $dateis "info" "container with name $PCCN is NOT stopped." >> $LOG_FILE
                echo "DNIF core-v9 podman container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        pre_act_containarconf
    fi
#--------------------------------------------------------------------
    if [[ $os == "ubuntu" ]] && [[ $LCCN == "console-v9" ]]; then        
        LOG_FILE="/DNIF/LC/log/Activity.log"
        docker stop console-v9 >> $LOG_FILE
        sleep 10 
        container_status=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $LCCN and ID $LCCID is stopped"
                echo $dateis "info" "container with name $LCCN is stopped." >> $LOG_FILE
                echo "DNIF console-v9 docker container is stopped"
            else
                #echo -e "container with name $LCCN and ID $LCCID is not stopped"
                echo $dateis "info" "container with name $LCCN is NOT stopped." >> $LOG_FILE
                echo "DNIF console-v9 docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $LCCN == "console-v9" ]]; then        
        LOG_FILE="/DNIF/LC/log/Activity.log"
        docker stop console-v9 >> $LOG_FILE
        sleep 10 
        container_status=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $LCCN and ID $LCCID is stopped"
                echo $dateis "info" "container with name $LCCN is stopped." >> $LOG_FILE
                echo "DNIF console-v9 docker container is stopped"
            else
                #echo -e "container with name $LCCN and ID $LCCID is not stopped"
                echo $dateis "info" "container with name $LCCN is NOT stopped." >> $LOG_FILE
                echo "DNIF console-v9 docker container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PLCCN == "console-v9" ]]; then        
        LOG_FILE="/DNIF/LC/log/Activity.log"
        podman stop console-v9 >> $LOG_FILE
        sleep 10 
        container_status=$(podman ps -a --filter "name=console-v9" --format "{{.Status}}")

            if [[ $container_status == *"Exited"* ]]; then      
                #echo -e "container with name $LCCN and ID $LCCID is stopped"
                echo $dateis "info" "container with name $PLCCN is stopped." >> $LOG_FILE
                echo "DNIF console-v9 podman container is stopped"
            else
                #echo -e "container with name $LCCN and ID $LCCID is not stopped"
                echo $dateis "info" "container with name $PLCCN is NOT stopped." >> $LOG_FILE
                echo "DNIF console-v9 podman container is NOT stopped"
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        pre_act_containarconf
    fi

fi