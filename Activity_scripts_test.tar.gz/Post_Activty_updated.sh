if [[ $EUID -ne 0 ]]; then
	echo -e "This script must be run as root ... \e[1;31m[ERROR] \e[0m\n"
    exit 1
else
    os=$(. /etc/os-release && echo -e "$ID")
    dateis=$(date '+%Y-%m-%dT%H:%M:%S')
    #variable depending on OS and Container
    #LOG_FILE="/DNIF/Activity/log/Activity.log"
  
    if [ $os == "ubuntu" ]; then
        PCN=$(docker ps -a --format '{{.Names}}' | grep -w pico-v9)
        ACN=$(docker ps -a --format '{{.Names}}' | grep -w adapter-v9)
        DCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-v9)
        MDCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        CCN=$(docker ps -a --format '{{.Names}}' | grep -w core-v9)
        LCCN=$(docker ps -a --format '{{.Names}}' | grep -w console-v9)
        #PCID=$(docker ps -aqf "name=pico-v9") 
        #ACID=$(docker ps -aqf "name=adapter-v9")
        #DCID=$(docker ps -aqf "name=datanode-v9")
        #CCID=$(docker ps -aqf "name=core-v9")
        #MDCID=$(docker ps -aqf "name=datanode-master-v9")
        #LCCID=$(docker ps -aqf "name=console-v9")
    fi

    if [ $os == "centos" ]; then
        PCN=$(docker ps -a --format '{{.Names}}' | grep -w pico-v9)
        ACN=$(docker ps -a --format '{{.Names}}' | grep -w adapter-v9)
        DCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-v9)
        MDCN=$(docker ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        CCN=$(docker ps -a --format '{{.Names}}' | grep -w core-v9)
        LCCN=$(docker ps -a --format '{{.Names}}' | grep -w console-v9)
        #PCID=$(docker ps -aqf "name=pico-v9") 
        #ACID=$(docker ps -aqf "name=adapter-v9")
        #DCID=$(docker ps -aqf "name=datanode-v9")
        #CCID=$(docker ps -aqf "name=core-v9")
        #MDCID=$(docker ps -aqf "name=datanode-master-v9")
        #LCCID=$(docker ps -aqf "name=console-v9")
    fi    
    
    if [ $os == "rhel" ]; then
        PPCN=$(podman ps -a --format '{{.Names}}' | grep -w pico-v9)
        PACN=$(podman ps -a --format '{{.Names}}' | grep -w adapter-v9)
        PDCN=$(podman ps -a --format '{{.Names}}' | grep -w datanode-v9)
        PMDCN=$(podman ps -a --format '{{.Names}}' | grep -w datanode-master-v9)
        PCCN=$(podman ps -a --format '{{.Names}}' | grep -w core-v9)
        PLCCN=$(podman ps -a --format '{{.Names}}' | grep -w console-v9)
        #PPCID=$(podman ps -aqf "name=pico-v9") 
        #PACID=$(podman ps -aqf "name=adapter-v9")
        #PDCID=$(podman ps -aqf "name=datanode-v9")
        #PCCID=$(podman ps -aqf "name=core-v9")
        #PMDCID=$(podman ps -aqf "name=datanode-master-v9")
        #PLCCID=$(podman ps -aqf "name=console-v9")   
    fi
function post_act_containarconf() {
    proxy_check_true=$(grep "#http_proxy = true" /usr/share/containers/containers.conf)
    proxy_check_false=$(grep "http_proxy = false" /usr/share/containers/containers.conf)
    proxy_check_true_dnif=$(grep "#http_proxy = true" /DNIF/backUp/containers.conf_dnif_pre_act)
    proxy_check_false_dnif=$(grep "http_proxy = false" /DNIF/backUp/containers.conf_dnif_pre_act)

    echo "$dateis info proxy_check_true: $proxy_check_true" >> $LOG_FILE
    echo "$dateis info proxy_check_false: $proxy_check_false" >> $LOG_FILE
    echo "$dateis info proxy_check_true_dnif: $proxy_check_true_dnif" >> $LOG_FILE
    echo "$dateis info proxy_check_false_dnif: $proxy_check_false_dnif" >> $LOG_FILE

    cp /usr/share/containers/containers.conf /DNIF/backUp/containers.conf_dnif_post_act_$dateis
    mv /DNIF/backUp/containers.conf_dnif_pre_act /usr/share/containers/containers.conf
    #file_check_post=$(ls /DNIF/backUp/ | grep -i "containers.conf_dnif_post_act")
    
    #if [[ $file_check_post == "containers.conf_dnif_post_act_$dateis" ]]; then
    #    echo "$dateis info Continers.conf successfully copied from /usr/share/containers/containers.conf to /DNIF/backUp/containers.conf_dnif_post_act_$dateis" >> $LOG_FILE
    #else
    #    echo "$dateis info Continers.conf not successfully copied from /usr/share/containers/containers.conf to /DNIF/backUp/" >> $LOG_FILE
    #fi

    file_check_conf=$(ls /usr/share/containers/ | grep -i "containers.conf")
    if [[ $file_check_conf == "containers.conf" ]]; then
        echo "$dateis info Continers.conf successfully copied from /DNIF/backUp/containers.conf_dnif_pre_act to /usr/share/containers/containers.conf" >> $LOG_FILE
    else
        echo "$dateis info Continers.conf not successfully copied from /DNIF/backUp/containers.conf_dnif_pre_act to /usr/share/containers/containers.conf" >> $LOG_FILE
    fi    

}

    if [[ $os == "ubuntu" ]] && [[ $PCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        container_status=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the docker container........" >> $LOG_FILE
                docker start pico-v9 >> $LOG_FILE
                #echo $dateis "info" "container with name $PCN is NOT stopped." >> $LOG_FILE
                sleep 120
                container_status_new=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "DNIF PICO container is Up and Running"
                    echo $dateis "info" "Started container with name $PCN is Up and Running" >> $LOG_FILE
                fi     
            else
                #echo -e "container with name $PCN and ID $PCID is Up and Running"
                echo -e "DNIF PICO container is Up and Running"
                echo $dateis "info" "Started container with name $PCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $PCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        container_status=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the docker container........" >> $LOG_FILE
                docker start pico-v9 >> $LOG_FILE
                #echo $dateis "info" "container with name $PCN is NOT stopped." >> $LOG_FILE
                sleep 120
                container_status_new=$(docker ps -a --filter "name=pico-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "DNIF PICO container is Up and Running"
                    echo $dateis "info" "Started container with name $PCN is Up and Running" >> $LOG_FILE
                fi     
            else
                #echo -e "container with name $PCN and ID $PCID is Up and Running"
                echo -e "DNIF PICO container is Up and Running"
                echo $dateis "info" "Started container with name $PCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PPCN == "pico-v9" ]]; then      
        LOG_FILE="/DNIF/PICO/log/Activity.log"
        post_act_containarconf
        container_status=$(podman ps -a --filter "name=pico-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                post_act_containarconf
                echo -e "podman container is exited"
                echo $dateis "info" "podman container is exited" >> $LOG_FILE
                echo -e "Starting the podman container........"
                echo $dateis "info" "Starting the podman container........" >> $LOG_FILE
                podman start pico-v9 >> $LOG_FILE
                #echo $dateis "info" "container with name $PCN is NOT stopped." >> $LOG_FILE
                sleep 120
                container_status_new=$(podman ps -a --filter "name=pico-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "DNIF PICO container is Up and Running"
                    echo $dateis "info" "Started container with name $PPCN is Up and Running" >> $LOG_FILE
                fi     
            else
                #echo -e "container with name $PCN and ID $PCID is Up and Running"
                echo -e "DNIF PICO container is Up and Running"
                echo $dateis "info" "Started container with name $PPCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi
#---------------------------------------------

    if [[ $os == "ubuntu" ]] && [[ $ACN == "adapter-v9" ]]; then      
        LOG_FILE="/DNIF/AD/log/Activity.log"
        container_status=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the Docker container........" >> $LOG_FILE
                docker start adapter-v9 >> $LOG_FILE
                sleep 120
                container_status_new=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $ACN and ID $ACID is Up and Running"
                    echo -e "DNIF Adapter container is Up and Running"
                    echo $dateis "info" "Started container with name $ACN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $ACN and ID $ACID is Up and Running"
                echo -e "DNIF Adapter container is Up and Running"
                echo $dateis "info" "Started container with name $ACN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $ACN == "adapter-v9" ]]; then      
        LOG_FILE="/DNIF/AD/log/Activity.log"
        container_status=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the Docker container........" >> $LOG_FILE
                docker start adapter-v9 >> $LOG_FILE
                sleep 120
                container_status_new=$(docker ps -a --filter "name=adapter-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $ACN and ID $ACID is Up and Running"
                    echo -e "DNIF Adapter container is Up and Running"
                    echo $dateis "info" "Started container with name $ACN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $ACN and ID $ACID is Up and Running"
                echo -e "DNIF Adapter container is Up and Running"
                echo $dateis "info" "Started container with name $ACN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PACN == "adapter-v9" ]]; then      
        LOG_FILE="/DNIF/AD/log/Activity.log"
        post_act_containarconf
        container_status=$(podman ps -a --filter "name=adapter-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                post_act_containarconf
                echo -e "podman container is exited"
                echo $dateis "info" "podman container is exited" >> $LOG_FILE
                echo -e "Starting the podman container........"
                echo $dateis "info" "Starting the podman container........" >> $LOG_FILE
                docker start adapter-v9 >> $LOG_FILE
                sleep 120
                container_status_new=$(podman ps -a --filter "name=adapter-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $ACN and ID $ACID is Up and Running"
                    echo -e "DNIF Adapter container is Up and Running"
                    echo $dateis "info" "Started container with name $PACN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $ACN and ID $ACID is Up and Running"
                echo -e "DNIF Adapter container is Up and Running"
                echo $dateis "info" "Started container with name $PACN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi

#-----------------------------
function query_correlation_report() {
    servers=("query_server" "correlation_server" "report_server")

    for server in "${servers[@]}"
    do
        server_status=$(pgrep -f "$server" || true)
        if [[ -n "$server_status" ]]; then
            echo "$server is running"
            echo $dateis "info" "$server is running" >> $LOG_FILE
        else
            echo "$server is not running"
            echo $dateis "info" "$server is NOT running" >> $LOG_FILE
        fi
    done

    query_server_status=$(pgrep -f "query_server" || true)
    correlation_server_status=$(pgrep -f "correlation_server" || true)
    report_server_status=$(pgrep -f "report_server" || true)

    if [[ -n "$query_server_status" && -n "$correlation_server_status" && -n "$report_server_status" ]]; then
        echo "query_correlation_report server's are running"
        echo $dateis "info" "query_correlation_report server's are running" >> $LOG_FILE
    else
        echo -e "Restarting spark-master.service and spark-slave.service...................."
        echo $dateis "info" "Restarting spark-master.service and spark-slave.service...................." >> $LOG_FILE
        systemctl restart spark-master.service spark-slave.service >> $LOG_FILE
        sleep 120
        query_server_status_new=$(pgrep -f "query_server" || true)
        correlation_server_status_new=$(pgrep -f "correlation_server" || true)
        report_server_status_new=$(pgrep -f "report_server" || true)
        if [[ -n "$query_server_status_new" && -n "$correlation_server_status_new" && -n "$report_server_status_new" ]]; then
            echo "query_correlation_report server's are running"
            echo $dateis "info" "query_correlation_report server's are running" >> $LOG_FILE
        fi
    fi
}
function check_hadoop_datanode_service() {
    hadoop_datanode_check=$(systemctl is-active hadoop-datanode.service)
    
    if [[ $hadoop_datanode_check == "active" ]]; then
        echo -e "Hadoop datanode service is active and running"
        echo $dateis "info" "Hadoop datanode service is active and running" >> $LOG_FILE
    else
        echo -e "hadoop-datanode.service is not active"
        echo $dateis "info" "hadoop-datanode.service is not active" >> $LOG_FILE
        systemctl restart hadoop-datanode.service >> $LOG_FILE
        echo -e "Restarting hadoop-datanode.service..........."
        echo $dateis "info" "Restarting hadoop-datanode.service..........." >> $LOG_FILE
        sleep 10
        hadoop_datanode_check_new=$(systemctl is-active hadoop-datanode.service)
        if [[ $hadoop_datanode_check_new == "active" ]]; then
            echo -e "Restarted hadoop-datanode.service and it is active and running"
            echo $dateis "info" "Restarted hadoop-datanode.service and it is active and running" >> $LOG_FILE
        fi
    fi
}
function check_spark_status() {
    spark_slave_check=$(systemctl is-active spark-slave.service)
    spark_master_check=$(systemctl is-active spark-master.service)

    if [[ $spark_slave_check == "active" ]] && [[ $spark_master_check == "active" ]]; then
        echo "Spark master and slave both are active and running"
        echo $dateis "info" "Spark master and slave both are active and running" >> $LOG_FILE
    else
        if [[ $spark_slave_check == "failed" ]]; then 
            echo -e "spark-slave.service is not active"
            echo $dateis "info" "spark-slave.service is not active" >> $LOG_FILE
        fi
        if [[ $spark_master_check == "failed" ]]; then 
            echo -e "spark-master.service is not active"
            echo $dateis "info" "spark-master.service is not active" >> $LOG_FILE
        fi
        systemctl restart spark-master.service spark-slave.service >> $LOG_FILE
        echo -e "Restarting spark-master.service and spark-slave.service............"
        echo $dateis "info" "Restarting spark-master.service and spark-slave.service............" >> $LOG_FILE
        sleep 10 
        spark_slave_check_new=$(systemctl is-active spark-slave.service)
        spark_master_check_new=$(systemctl is-active spark-master.service)
        if [[ $spark_slave_check_new == "active" ]] && [[ $spark_master_check_new == "active" ]]; then
            echo "Restarted spark-master.service and spark-slave.service and it is active and running"
            echo $dateis "info" "Restarted spark-master.service and spark-slave.service and it is active and running" >> $LOG_FILE
        fi
    fi
}
function hadoop_namenode_check(){
    hadoop_namenode_check=$(systemctl is-active hadoop-namenode.service)            
    if [[ $hadoop_namenode_check == "active" ]]; then
        echo -e "Hadoop namenode service is active and running"
        echo $dateis "info" "Hadoop namenode service is active and running" >> $LOG_FILE
    else
        echo -e "Hadoop namenode service is not active"
        echo $dateis "info" "Hadoop namenode service is not active" >> $LOG_FILE
        systemctl restart hadoop-namenode.service >> $LOG_FILE
        echo -e "Restarting hadoop-namenode.service..............."
        echo $dateis "info" "Restarting hadoop-namenode.service..............." >> $LOG_FILE
        sleep 30
        hadoop_namenode_check_new=$(systemctl is-active hadoop-namenode.service) 
        if [[ $hadoop_namenode_check_new == "active" ]]; then
            echo -e "Restarted hadoop-namenode.service and it is active and running"
            echo $dateis "info" "Restarted hadoop-namenode.service and it is active and running" >> $LOG_FILE
        else
            echo -e "Hadoop namenode service is not active"
            echo $dateis "info" "Hadoop namenode service is not active" >> $LOG_FILE
        fi
    fi
}
#------------------------------

    if [[ $os == "ubuntu" ]] && [[ $DCN == "datanode-v9" ]]; then 
        LOG_FILE="/DNIF/DL/log/Activity.log"
        check_hadoop_datanode_service

        check_spark_status

        container_status=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the docker container........" >> $LOG_FILE
                docker start datanode-v9 >> $LOG_FILE          
                sleep 50
                container_status_new=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $DCN and ID $DCID is Up and Running"
                    echo -e "DNIF Datanode container is Up and Running"
                    echo $dateis "info" "Started container with name $DCN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $DCN and ID $DCID is Up and Running"
                echo -e "DNIF Datanode container is Up and Running"
                echo $dateis "info" "Started container with name $DCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
        
        query_correlation_report                
    fi
    
    if [[ $os == "centos" ]] && [[ $DCN == "datanode-v9" ]]; then 
        LOG_FILE="/DNIF/DL/log/Activity.log"
        check_hadoop_datanode_service

        check_spark_status

        container_status=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container is exited"
                echo $dateis "info" "Docker container is exited" >> $LOG_FILE
                echo -e "Starting the docker container........"
                echo $dateis "info" "Starting the docker container........" >> $LOG_FILE
                docker start datanode-v9 >> $LOG_FILE          
                sleep 50
                container_status_new=$(docker ps -a --filter "name=datanode-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $DCN and ID $DCID is Up and Running"
                    echo -e "DNIF Datanode container is Up and Running"
                    echo $dateis "info" "Started container with name $DCN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $DCN and ID $DCID is Up and Running"
                echo -e "DNIF Datanode container is Up and Running"
                echo $dateis "info" "Started container with name $DCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
        
        query_correlation_report                
    fi

    if [[ $os == "rhel" ]] && [[ $PDCN == "datanode-v9" ]]; then 
        LOG_FILE="/DNIF/DL/log/Activity.log"
        post_act_containarconf
        check_hadoop_datanode_service

        check_spark_status

        container_status=$(podman ps -a --filter "name=datanode-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "podman container is exited"
                echo $dateis "info" "podman container is exited" >> $LOG_FILE
                echo -e "Starting the podman container........"
                echo $dateis "info" "Starting the podman container........" >> $LOG_FILE
                podman start datanode-v9 >> $LOG_FILE          
                sleep 50
                container_status_new=$(podman ps -a --filter "name=datanode-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    #echo -e "container with name $DCN and ID $DCID is Up and Running"
                    echo -e "DNIF Datanode container is Up and Running"
                    echo $dateis "info" "Started container with name $PDCN is Up and Running" >> $LOG_FILE
                fi
            else
                #echo -e "container with name $DCN and ID $DCID is Up and Running"
                echo -e "DNIF Datanode container is Up and Running"
                echo $dateis "info" "Started container with name $PDCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
        
        query_correlation_report                
    fi
#---------------------------------
    if [[ $os == "ubuntu" ]] && [[ $CCN == "core-v9" ]]; then 
        LOG_FILE="/DNIF/CO/log/Activity.log"
        container_status_mdn=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")
            hadoop_namenode_check
            
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container for core is exited"
                echo $dateis "info" "Docker container for core is exited" >> $LOG_FILE
                echo -e "Starting the docker container for core ........."
                echo $dateis "info" "Starting the docker container for core ........." >> $LOG_FILE
                docker start core-v9 >> $LOG_FILE
                sleep 20
                container_status_new=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "container with name $CCN is Up and Running"
                    echo $dateis "info" "container with name $CCN is Up and Running" >> $LOG_FILE
                fi 
            else
                echo -e "container with name $CCN is Up and Running"
                echo $dateis "info" "container with name $CCN is Up and Running" >> $LOG_FILE
            fi
            if [[ $container_status_mdn == *"Exited"* ]]; then      
                echo -e "Docker container for Master-Datanode is exited"
                echo $dateis "info" "Docker container for Master-Datanode is exited" >> $LOG_FILE
                echo -e "Starting the docker container for Master-Datanode ........."
                echo $dateis "info" "Starting the docker container for Master-Datanode ........." >> $LOG_FILE
                docker start datanode-master-v9 >> $LOG_FILE
                sleep 20
                container_status_mdn_new=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
                if [[ $container_status_mdn_new == *"Up"* ]]; then   
                    echo -e"container with name $MDCN is Up and Running"
                    echo $dateis "info" "container with name $MDCN is Up and Running" >> $LOG_FILE
                fi
            else 
                echo -e "container with name $MDCN is Up and Running"
                echo $dateis "info" "container with name $MDCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"    
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $CCN == "core-v9" ]]; then 
        LOG_FILE="/DNIF/CO/log/Activity.log"
        container_status_mdn=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")
            hadoop_namenode_check
            
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container for core is exited"
                echo $dateis "info" "Docker container for core is exited" >> $LOG_FILE
                echo -e "Starting the docker container for core ........."
                echo $dateis "info" "Starting the docker container for core ........." >> $LOG_FILE
                docker start core-v9 >> $LOG_FILE
                sleep 20s
                container_status_new=$(docker ps -a --filter "name=core-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "container with name $CCN is Up and Running"
                    echo $dateis "info" "container with name $CCN is Up and Running" >> $LOG_FILE
                fi 
            else
                echo -e "container with name $CCN is Up and Running"
                echo $dateis "info" "container with name $CCN is Up and Running" >> $LOG_FILE
            fi
            if [[ $container_status_mdn == *"Exited"* ]]; then      
                echo -e "Docker container for Master-Datanode is exited"
                echo $dateis "info" "Docker container for Master-Datanode is exited" >> $LOG_FILE
                echo -e "Starting the docker container for Master-Datanode ........."
                echo $dateis "info" "Starting the docker container for Master-Datanode ........." >> $LOG_FILE
                docker start datanode-master-v9 >> $LOG_FILE
                sleep 20
                container_status_mdn_new=$(docker ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
                if [[ $container_status_mdn_new == *"Up"* ]]; then   
                    echo -e "container with name $MDCN is Up and Running"
                    echo $dateis "info" "container with name $MDCN is Up and Running" >> $LOG_FILE
                fi
            else 
                echo -e "container with name $MDCN is Up and Running"
                echo $dateis "info" "container with name $MDCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"    
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PCCN == "core-v9" ]]; then 
        LOG_FILE="/DNIF/CO/log/Activity.log"
        post_act_containarconf
        container_status_mdn=$(podman ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
        container_status=$(podman ps -a --filter "name=core-v9" --format "{{.Status}}")
            hadoop_namenode_check
            
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "podman container for core is exited"
                echo $dateis "info" "podman container for core is exited" >> $LOG_FILE
                echo -e "Starting the podman container for core ........."
                echo $dateis "info" "Starting the podman container for core ........." >> $LOG_FILE
                podman start core-v9 >> $LOG_FILE
                container_status_new=$(podman ps -a --filter "name=core-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then
                    echo -e "container with name $PCCN is Up and Running"
                    echo $dateis "info" "container with name $PCCN is Up and Running" >> $LOG_FILE
                fi 
            else
                echo -e "container with name $PCCN is Up and Running"
                echo $dateis "info" "container with name $PCCN is Up and Running" >> $LOG_FILE
            fi
            if [[ $container_status_mdn == *"Exited"* ]]; then      
                echo -e "podman container for Master-Datanode is exited"
                echo $dateis "info" "podman container for Master-Datanode is exited" >> $LOG_FILE
                echo -e "Starting the podman container for Master-Datanode ........."
                echo $dateis "info" "Starting the podman container for Master-Datanode ........." >> $LOG_FILE
                podman start datanode-master-v9 >> $LOG_FILE
                container_status_mdn_new=$(podman ps -a --filter "name=datanode-master-v9" --format "{{.Status}}")
                if [[ $container_status_mdn_new == *"Up"* ]]; then   
                    echo -e "container with name $PMDCN is Up and Running"
                    echo $dateis "info" "container with name $PMDCN is Up and Running" >> $LOG_FILE
                fi
            else 
                echo -e "container with name $PMDCN is Up and Running"
                echo $dateis "info" "container with name $PMDCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(podman ps -a)"    
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi
#---------------------------

    if [[ $os == "ubuntu" ]] && [[ $LCCN == "console-v9" ]]; then      
        LOG_FILE="/DNIF/LC/log/Activity.log"
        container_status=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container For Console is exited"
                echo $dateis "info" "Docker container for Console is exited" >> $LOG_FILE
                echo -e "Starting the docker container for console........"
                echo $dateis "info" "Starting the docker container for Console........" >> $LOG_FILE
                docker start console-v9 >> $LOG_FILE
                container_status_new=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then 
                    echo -e "container with name $LCCN is Up and Running"
                    echo $dateis "info" "container with name $LCCN is Up and Running" >> $LOG_FILE
                fi
            else
                echo -e "container with name $LCCN is Up and Running"
                echo $dateis "info" "container with name $LCCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "centos" ]] && [[ $LCCN == "console-v9" ]]; then      
        LOG_FILE="/DNIF/LC/log/Activity.log"
        container_status=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "Docker container For Console is exited"
                echo $dateis "info" "Docker container For Console is exited" >> $LOG_FILE
                echo -e "Starting the docker container For Console........"
                echo $dateis "info" "Starting the docker container For Console........" >> $LOG_FILE
                docker start console-v9 >> $LOG_FILE
                sleep 20
                container_status_new=$(docker ps -a --filter "name=console-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then 
                    echo -e "container with name $LCCN is Up and Running"
                    echo $dateis "info" "container with name $LCCN is Up and Running" >> $LOG_FILE
                fi
            else
                echo -e "container with name $LCCN is Up and Running"
                echo $dateis "info" "container with name $LCCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(docker ps -a)"
        echo $dateis "info" "$(docker ps -a )" >> $LOG_FILE
    fi

    if [[ $os == "rhel" ]] && [[ $PLCCN == "console-v9" ]]; then      
        LOG_FILE="/DNIF/LC/log/Activity.log"
        post_act_containarconf
        container_status=$(podman ps -a --filter "name=console-v9" --format "{{.Status}}")
            if [[ $container_status == *"Exited"* ]]; then      
                echo -e "podman container For Console is exited"
                echo $dateis "info" "podman container For Console is exited" >> $LOG_FILE
                echo -e "Starting the podman container For Console........"
                echo $dateis "info" "Starting the podman container For Console........" >> $LOG_FILE
                podman start console-v9 >> $LOG_FILE
                container_status_new=$(podman ps -a --filter "name=console-v9" --format "{{.Status}}")
                if [[ $container_status_new == *"Up"* ]]; then 
                    echo -e "container with name $PLCCN is Up and Running"
                    echo $dateis "info" "container with name $PLCCN is Up and Running" >> $LOG_FILE
                fi
            else
                echo -e "container with name $PLCCN is Up and Running"
                echo $dateis "info" "container with name $PLCCN is Up and Running" >> $LOG_FILE
            fi
        #echo -e "$(podman ps -a)"
        echo $dateis "info" "$(podman ps -a )" >> $LOG_FILE
    fi
fi