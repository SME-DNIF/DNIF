import os
import shutil

# Create the directory
backup_directory = '/DNIF/addon/backup/'
os.makedirs(backup_directory, exist_ok=True)

# Content of backup.py
backup_py_content = """
import glob
import os
import hashlib
import tarfile
import hashlib
import logging
import yaml
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
import subprocess
import sys
import shutil

with open('/DNIF/addon/backup/backup.yaml', 'r') as config_file:
    config = yaml.safe_load(config_file)

# Set the log level based on the configuration
log_level_numeric = config.get('log_level', 0)
log_level = logging.INFO if log_level_numeric else logging.DEBUG

# Configure the logging settings
logging.basicConfig(level=log_level,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')


# Create a rotating file handler
log_directory = '/DNIF/addon/backup/log'
os.makedirs(log_directory, exist_ok=True)

log_filename = os.path.join(log_directory, 'backup.log')
handler = RotatingFileHandler(log_filename, maxBytes=10 * 1024 * 1024, backupCount=20)

# Configure the handler format
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)

# Add the handler to the root logger
logging.getLogger('').addHandler(handler)

config_file = "/etc/dnif-bar/config.yaml"
mountpoint = subprocess.check_output(['awk', '/backup_mount_point/ {print $2}', config_file]).decode('utf-8').strip()
scope = subprocess.check_output(['awk', '/scope:/ {print $2}', '/DNIF/addon/backup/backup.yaml']).decode('utf-8').strip()
dstpath = subprocess.check_output(['awk', '/dstpath/ {print $2}', '/DNIF/addon/backup/backup.yaml']).decode('utf-8').strip()
backup_archive = subprocess.check_output(['awk', '/backup_archive/ {print $2}', '/DNIF/addon/backup/backup.yaml']).decode('utf-8').strip()
current_date = datetime.now()
def final_backup(config_file, mountpoint, scope, dstpath, backup_archive,):
    try:
        find_command = f'find "{mountpoint}/{backup_archive}/DNIF/events/Scope={scope}/" -type f -name "Day={day}.zip"'
        result = subprocess.run(find_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        dfi_streams = result.stdout.splitlines()

        #variables = ["config_file", "mountpoint", "scope", "dstpath", "backup_archive",
        #                "current_date", "days_ago", "day", "dfi_streams"]

        #for var in variables:
        #    logging.debug(f"{var}:{locals()[var]}")

        if not all((mountpoint, scope, dstpath, backup_archive)):
            logging.error("Invalid configuration. Check mountpoint, scope, dstpath, and backup_archive.")
            return

        if dfi_streams:
            logging.info(f"Data found for {day}. Proceeding with further steps.")

            #def calculate_md5_old(data):
            #    if isinstance(data, str):
            #        data = data.encode('utf-8')  # Encode Unicode string to bytes
            #    md5 = hashlib.md5()
            #    md5.update(data)
            #    return md5.hexdigest()

            def calculate_md5(file_path):
                md5 = hashlib.md5()
                with open(file_path, 'rb') as file:
                    # Read and update hash string value in blocks of 4K
                    for byte_block in iter(lambda: file.read(4096), b""):
                        md5.update(byte_block)
                return md5.hexdigest()

            def calculate_md5_for_multiple_files(file_paths):
                md5_dict = {}
                for file_path in file_paths:
                    if os.path.isfile(file_path) and file_path.lower().endswith('.zip'):
                        md5_sum = calculate_md5(file_path)
                        md5_dict[file_path] = md5_sum
                return md5_dict

            md5_results = calculate_md5_for_multiple_files(dfi_streams)

            if md5_results:
                logging.debug(f"md5_result:{md5_results}")

            def tar_create():
                tar_filename = os.path.join(dstpath, f'{day}_{scope}.tar.gz')
                with tarfile.open(tar_filename, "w:gz") as tar:
                    for file_path in dfi_streams:
                        # Use the full path as the arcname to maintain directory structure
                        arcname = file_path
                        tar.add(file_path, arcname=arcname)

                # Return the tar_filename
                return tar_filename

            tar_gz_path = tar_create()

            if tar_gz_path:
                logging.info(f"tar file is successfully created for all stream of the day {day} at {tar_gz_path}")
                backup_directory = '/DNIF/addon/backup/'
                os.makedirs(backup_directory, exist_ok=True)
                bookmark_filename = os.path.join(backup_directory, 'bookmark.yaml')
                # Write the content to files
                with open(bookmark_filename, 'w') as bookmark_yaml_file:
                    bookmark_yaml_file.write(day)
            else:
                logging.info(f"No tar file created due to empty dfi_streams")
                logging.debug(f"dfi_streams:{dfi_streams}")

            def calculate_md5_tar(data):
                if isinstance(data, str):
                    data = data.encode('utf-8')  # Encode Unicode string to bytes
                md5 = hashlib.md5()
                md5.update(data)
                return md5.hexdigest()

            def get_md5_for_tar_gz(tar_gz_path):
                md5_dict = {}

                with tarfile.open(tar_gz_path, "r:gz") as tar:
                    for member in tar.getmembers():
                        # Extract the content of each file in the archive
                        file_data = tar.extractfile(member).read()
                        md5_sum = calculate_md5_tar(file_data)
                        md5_dict[member.name] = md5_sum

                return md5_dict

            md5_results_tar = get_md5_for_tar_gz(tar_gz_path)

            if md5_results_tar:
                logging.debug(f"md5_results_tar: {md5_results_tar}")

            md5_results_tar_with_slash = {f'/{key}': value for key, value in md5_results_tar.items()}

            if md5_results_tar:
                logging.debug(f"md5_results_tar_with_slash: {md5_results_tar_with_slash}")

            # Compare MD5 checksums
            def compare_md5sums(md5_results_tar_with_slash, md5_results, day):
                for file_path, md5_sum in md5_results.items():
                    md5_sum_tar = md5_results_tar_with_slash.get(file_path)
                    if md5_sum_tar is not None:
                        if md5_sum == md5_sum_tar:
                            logging.info(f"MD5 checksums match for file: {file_path}")
                            logging.info(f"Proceeding with the deletion of data for {file_path}")
                            try:
                                os.remove(file_path)
                                logging.info(f"File deleted: {file_path}")
                            except OSError as e:
                                logging.error(f"Error deleting file {file_path} on {day}: {e}")
                        else:
                            logging.info(f"MD5 checksums do not match for file: {file_path}")
                    else:
                        logging.debug(f"File not found in md5_results_tar_with_slash: {file_path}")
                        logging.info(f"File not found")

            # Compare MD5 checksums
            compare_md5sums(md5_results_tar_with_slash, md5_results, day)
        else:
            logging.info(f"Data not found for {day}")
            logging.debug(f"dfi_streams: {dfi_streams}")

            tar_filename_new = f'{dstpath}/{day}_default.tar.gz'
            if os.path.exists(tar_filename_new):
                logging.info(f"Tar file already present for {day}")
    except Exception as e:
        logging.error(f"An error occurred: {e}")

bookmark_file = "/DNIF/addon/backup/bookmark.yaml"  # replace with the actual path
if os.path.isfile(bookmark_file):
    try:
        # Use with open to read the contents of the file
        with open(bookmark_file, 'r') as file:
            bookmark_value = file.read().strip()
        # Use datetime.strptime to convert the bookmark_value to datetime
        start_date = datetime.strptime(bookmark_value, "%Y%m%d")

        # Calculate day before yesterday's date
        before_yesterday = datetime.now() - timedelta(days=2)

        # Generate a list of dates from start_date to yesterday (excluding start_date)
        date_range = [start_date + timedelta(days=x) for x in range(1, (before_yesterday - start_date).days + 1)]
        date_list = [] 
        date_list.extend(date.strftime("%Y%m%d") for date in date_range)
        for day in date_list:
            final_backup(config_file, mountpoint, scope, dstpath, backup_archive)
        # Print the list of dates
    except Exception as e:
        logging.info(f"Error reading bookmark file: {e}")
else:
    older_than_day = int(config.get('older_than_day', 0))
    current_date = datetime.now()
    days_ago = current_date - timedelta(days=older_than_day)
    day = days_ago.strftime('%Y%m%d')
    final_backup(config_file, mountpoint, scope, dstpath, backup_archive,)
"""

# Content of backup.yaml
backup_yaml_content = """
#provide the scope name 
scope: default
#choose anyone from the backup/archive
backup_archive: backup
#provide destination path 
dstpath: /DNIF/MIG-NEW-TEST
log_level: 0
older_than_day: 1
"""

# Path for backup.py and backup.yaml in the created directory
backup_py_path = os.path.join(backup_directory, 'backup.py')
backup_yaml_path = os.path.join(backup_directory, 'backup.yaml')

# Write the content to files
with open(backup_py_path, 'w') as backup_py_file:
    backup_py_file.write(backup_py_content)

with open(backup_yaml_path, 'w') as backup_yaml_file:
    backup_yaml_file.write(backup_yaml_content)


print(f"Successfully created a backup.yaml file at the path /DNIF/addon/backup/ and made the necessary required changes to the file")


